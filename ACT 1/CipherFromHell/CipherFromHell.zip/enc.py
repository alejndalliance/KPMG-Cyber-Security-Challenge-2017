#!/usr/bin/env python2
m = open("message").read()
k = raw_input("key: ").strip()
def gg(m, k):
    z = ""
    for i, c in enumerate(m):
        z += chr((ord(c)+ord(k[i%len(k)]))%256)
    return z
f = open("cipher", "wb")
f.write(gg(m, k))
f.close()
